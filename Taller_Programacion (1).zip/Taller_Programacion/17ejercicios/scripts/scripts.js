jQuery('document').ready(function($){
   var menuBtn = $('.menu-icon');
   var menu = $('.navigation ul');
   var cedulas = new Array();
   var estudiantes = new Array();
   var edades = new Array();
   var matrices=new Array();
   var objestudiantes=new Array();
   
   var formulario=document.getElementById('formulario');
          formulario.addEventListener('submit',function(e){
           e.preventDefault();
        })
  

   
      menuBtn.click(function(){


        if (menu.hasClass('show')) {
          menu.removeClass('show');
        }else{
          menu.addClass('show');
      
        };
      });

    

      $("#botonsuma").click(function () {
         
          var n1 = Number(prompt('Ingresa el primer numero '));
          var n2 = Number(prompt('Ingresa el segundo numero '));

          var suma=n1+n2;
        
          alert(n1+" + " + n2 +" = "+ suma); 
       });



      $("#botonarea").click(function () {

          var base = Number (prompt('Ingresa la base del rectangulo '));
          var altura = Number (prompt('Ingresa la altura del rectangulo '));
         
           var area=base*altura;
            alert(" El area del rectangulo es de:" + base +" * " + altura +" = "+ area);
      });


    $("#botonnotas").click(function () {

        var corte1 = parseFloat(prompt("Ingrese la nota del primer corte: "));
        var corte2 = parseFloat(prompt("Ingrese la nota del segundo corte: "));
         var corte3 = parseFloat(prompt("Ingrese la nota del tercer corte: "));

        var notaFinal = (corte1 * 0.3) + (corte2 * 0.3) + (corte3 * 0.4);
        
         
           alert("La nota final en la asignatura es: " + notaFinal);
      });


       $("#botoncircunferencia").click(function () {

         var valorradio = parseFloat(prompt("Ingrese el valor del radio de la circunferencia "));
         var pi= 3.1416;
 
       var area = pi * (valorradio*valorradio);

         alert("El área de la circunferencia es de " + area);
                 

                  });
     
       $("#botonterreno").click(function () {

          var base= parseFloat(prompt("Ingrese la medida de la base del terreno "));
          var alturamayor= parseFloat(prompt("Ingrese la medida de la altura mas alta del terreno "));
          var alturamenor= parseFloat(prompt("Ingrese la medida de la altura menor del terreno "));
          
         var areatriangulo= base * (alturamayor-alturamenor)/2;
         var arearectangulo = base*alturamenor;
         var areafigura= areatriangulo + arearectangulo;
 
      

         alert("El área del terreno es de " + areafigura);

        });


    
       $("#areasterrenos").click(function () {
        var hipotenusa= Number(prompt("Ingrese el valor de la hipotenusa del terreno "));
        var radio= Number(prompt("Ingrese el valor del radio del terreno "));
      

        var altura=(hipotenusa*hipotenusa) - (radio*radio);  
         var raizCuadrada = Math.sqrt(altura);

        var areatriangulo = ((radio*raizCuadrada)/2)*2;
        var areacirculo= 3.1416*(radio*radio)/2;

        var areafigura = areatriangulo+areacirculo;

        alert("El área del terreno es de " + areafigura.toFixed(2));
          
      });


    $("#produccionleche").click(function () {
        var litro= Number(prompt("Ingrese la cantidad de litros que produjo en el día"));
        var preciolitro= Number(prompt("Ingrese el precio equivalente a cada litro "));

        var galon=3.785;

        var cantidad = litro/ galon;
        var totaldinero= preciolitro*cantidad;
      
        alert("la cantidad de galones que vendio en el dia es de: "  + cantidad.toFixed(2) + 
            "El total de dinero que recibira por la produccion de leche en el dia es de: " + totaldinero.toFixed(2));
          
      });


 $("#distancia").click(function () {
    var x1 = parseFloat(prompt("Ingrese el valor de X del punto 1"));
    var y1 = parseFloat(prompt("Ingrese el valor de Y del punto 1"));
    var x2 = parseFloat(prompt("Ingrese el valor de X del punto 2"));
    var y2 = parseFloat(prompt("Ingrese el valor de Y del punto 2"));

    var distanciaX = (x2 - x1);
    var distanciaY = (y2 - y1);

    var distancia = Math.sqrt(distanciaX * distanciaX + distanciaY * distanciaY);

    alert('La distancia entre los puntos (' + x1 + ', ' + y1 + ') y (' + x2 + ', ' + y2 + ') es: ' + distancia.toFixed(2));
});

   

 $("#conversion").click(function () {
    var metros = parseFloat(prompt("Ingrese las medidas que necesita de la tela en metros"));
  
  var pulgada= 0.0254;

    var totalpulgadas= metros/pulgada;
   

    alert("La cantidad de tela que necesita es de: " + totalpulgadas.toFixed(2) + " pulgadas ");
});

      
      $("#PagoAgua").click(function() {

var costoMetro = parseFloat(prompt("Ingrese el precio por metro cúbico de agua: "));

var cantidadAlbercas = parseInt(prompt("Ingrese la cantidad de albercas que desea llenar: "));

var totalpagar = 0; 

for (var i = 1; i <= cantidadAlbercas; i++) {
    var largo = parseFloat(prompt('Ingrese el largo de la alberca ' + i + ' en metros:'));
    var ancho = parseFloat(prompt('Ingrese el ancho de la alberca ' + i + ' en metros:'));
    var altura = parseFloat(prompt('Ingrese la profundidad de la alberca ' + i + ' en metros:'));

    var volumen = largo * ancho * altura;

    var costoAlberca = volumen * costoMetro;
    
    
    totalpagar += costoAlberca;
}


alert('El costo total a pagar por llenar ' + cantidadAlbercas + ' albercas es: $' + totalpagar.toFixed(0));


});









});


  











