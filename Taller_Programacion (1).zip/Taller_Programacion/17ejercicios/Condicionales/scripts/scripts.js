jQuery('document').ready(function($){
   var menuBtn = $('.menu-icon');
   var menu = $('.navigation ul');
   var cedulas = new Array();
   var estudiantes = new Array();
   var edades = new Array();
   var matrices=new Array();
   var objestudiantes=new Array();
   
   var formulario=document.getElementById('formulario');
          formulario.addEventListener('submit',function(e){
           e.preventDefault();
        })
  

   
      menuBtn.click(function(){


        if (menu.hasClass('show')) {
          menu.removeClass('show');
        }else{
          menu.addClass('show');
      
        };
      });

    

      $("#numeromayor").click(function () {

          var valor1 = Number(prompt('Ingresa el primer valor '));
          var valor2 = Number(prompt('Ingresa el segundo valor '));

          if (valor1>valor2){
            alert("El valor " + valor1 +" es mayor que "+ valor2);
          }

          else if (valor2>valor1) {
           alert("El valor " + valor2 +" es mayor que "+ valor1);
          }    

               else {
                 alert("Ninguno de los numeros anteriores es mayor ya que " + valor1 +" y " + valor2 + " son iguales ");
               }
      });


       $("#determinarnumero").click(function () {

        var numero = Number (prompt('Ingresa un número'));
      
        if (numero > 0) {
       alert("El numero ingresado " + numero + " es positivo ");
      }
       else if (numero < 0) {
       alert("El numero ingresado es " + numero + " es negativo ");
    } else {
        alert("El numero ingresado es " + numero );
    }

    });

         $("#Totalpagar").click(function () {

        var cantidad = Number (prompt('Ingresa la cantidad de lapiceros que vas a comprar'));
      
         if (cantidad >= 1000) {
         precioUnidad = 1100;
         } else {
        precioUnidad = 1300;
         }

         var total= cantidad * precioUnidad;

          alert("El  total a pagar por " + cantidad + " es de " + total );
    });


    $("#descuento").click(function () {

        var precio = Number (prompt('Ingresa el valor del traje que deseas comprar'));
      
         if (precio >= 25000) {
            var descuento= precio * 0.17;
         }
          else {
            var descuento = precio * 0.05;
         }

         var totalpagar= precio - descuento;

          alert("El total a pagar es de " + totalpagar + " y el descuento que obtuvo fue de " + descuento);
    });

$("#arregloNumero").click(function () {

    var numero1 = Number(prompt('Ingresa el primer numero'));
    var numero2 = Number(prompt('Ingresa el segundo numero')); 
    var numero3 = Number(prompt('Ingresa el tercer numero')); 

    if (numero1 >= numero2 && numero1 >= numero3) {
       var mayor = numero1;
    } 
    else if (numero2 >= numero1 && numero2 >= numero3) {
        var mayor = numero2;
    } 
    else {
        var mayor = numero3;
    }

    var numerosOrdenados = [numero1, numero2, numero3];

    numerosOrdenados.sort((x, y) => y - x);

    alert("Los numeros ingresados ordenados de forma descendente son " + numerosOrdenados.join(', ') + " y el numero mayor es " + mayor);
});

  $("#presupuesto").click(function () {

    var cantidadPersonas = parseInt(prompt('Ingresa la cantidad de personas que asistiran al evento'));
    
     if (cantidadPersonas > 150) {
        costoPlato = 7500;
    } else if (cantidadPersonas > 90 && cantidadPersonas <= 150) {
        costoPlato = 8500;
    } else {
        costoPlato = 10000;
    }

    var totalpresupuesto = costoPlato * cantidadPersonas;



    alert("La cantidad de personas que asistiran al evento son " + cantidadPersonas + " por lo tanto el total a pagar es de $" + totalpresupuesto);
});
  
$("#precioCita").click(function () {
    var numeroCita = parseInt(prompt('Ingresa el número de la cita en la que vas del tratamiento'));
    

    if (numeroCita <= 3) {
       var costoCita = 100000;
    } else if (numeroCita > 3 && numeroCita <= 5) {
       var  costoCita = 80000;
    } else if (numeroCita > 5 && numeroCita <= 8) {
        var costoCita = 70000;
    } else {
        var costoCita = 50000;
    }

        var montoTratamiento = 0;

    for (var i = 1; i <= numeroCita; i++) {
        if (i <= 3) {
            montoTratamiento += 100000;
        } else if (i <= 5) {
            montoTratamiento += 80000;
        } else if (i <= 8) {
            montoTratamiento += 70000;
        } else {
            montoTratamiento += 50000;
        }
    }

    alert("El costo de la cita es: $" + costoCita + " y el valor total de todo el tratamiento hasta ahora es de $" + montoTratamiento);
});







});


  











