jQuery('document').ready(function($){
   var menuBtn = $('.menu-icon');
   var menu = $('.navigation ul');
   var cedulas = new Array();
   var estudiantes = new Array();
   var edades = new Array();
   var matrices=new Array();
   var objestudiantes=new Array();
   
   var formulario=document.getElementById('formulario');
          formulario.addEventListener('submit',function(e){
           e.preventDefault();
        })
  

   
      menuBtn.click(function(){


        if (menu.hasClass('show')) {
          menu.removeClass('show');
        }else{
          menu.addClass('show');
      
        };
      });

    

  $("#promedionotas").click(function () {
    var numeroEstudiantes = parseInt(prompt("Ingresa el número de estudiantes:"));
    var sumanota = 0;

    for (var i = 0; i < numeroEstudiantes; i++) {
        var nota = parseFloat(prompt("Ingresa la nota del estudiante " + (i + 1) + ":"));
        sumanota += nota; // Acumular las notas en sumanota
    }

    var promedioGeneral = sumanota / numeroEstudiantes; 

    alert("El promedio general del grupo de estudiantes es: " + promedioGeneral);
});




$("#estadisticaEstudiante").click(function () {
    var numeroEstudiantes = parseInt(prompt("Ingresa el número de estudiantes:"));
    var sumanota = 0;
    var aprobados = 0;
    var reprobados = 0;

    for (var i = 0; i < numeroEstudiantes; i++) {
         var nombre = (prompt ("Ingresa el nombre del estudiante " + (i + 1) + ":"));
          var cedula = parseFloat(prompt("Ingresa el numero de identificacion del estudiante " + (i + 1) + ":"));
        var nota = parseFloat(prompt("Ingresa la nota del estudiante " + (i + 1) + ":"));
        
        sumanota += nota; 

        if (nota >= 3.0) {
            aprobados++;
        } else {
            reprobados++;
        }
    }

    var promedioGeneral = sumanota / numeroEstudiantes;

    alert("La cantidad de alumnos aprobados es de: " + aprobados);
    alert("La cantidad de alumnos reprobados es de: " + reprobados);
    alert("El promedio general del grupo de estudiantes es: " + promedioGeneral);
});




   $("#numeros").click(function () {
    var cantidadNumeros = parseInt(prompt('Ingrese la cantidad de números en el grupo:'));

    var numeroMayor = -Infinity;
    var numeroMenor = Infinity;

    
    var cantidadMayoresA150 = 0;
    var cantidadNegativos = 0;

    
    var sumaPositivos = 0;
    var cantidadPositivos = 0;

    for (var i = 1; i <= cantidadNumeros; i++) {
        var numero = parseFloat(prompt('Ingrese el número ' + i + ':'));
        
    
        if (numero > numeroMayor) {
            numeroMayor = numero;
        }
        if (numero < numeroMenor) {
            numeroMenor = numero;
        }

        if (numero > 150) {
            cantidadMayoresA150++;
        }

        if (numero < 0) {
            cantidadNegativos++;
        }

        if (numero > 0) {
            sumaPositivos += numero;
            cantidadPositivos++;
        }
    }

   
    var promedioPositivos = 0;
    if (cantidadPositivos > 0) {
        promedioPositivos = sumaPositivos / cantidadPositivos;
    }

    alert('Número mayor: ' + numeroMayor);
    alert('Número menor: ' + numeroMenor);
    alert('Cantidad de números mayores a 150: ' + cantidadMayoresA150);
    alert('Cantidad de números negativos: ' + cantidadNegativos);
    alert('Promedio de los números positivos: ' + promedioPositivos.toFixed(2));
  });




    $("#grupoPromedio").click(function () {
      var cantidadEstudiantes = parseInt(prompt('Ingrese la cantidad de estudiantes que estan en el grupo:'));
  
  
      var promedioGrupo = 0;
  
      for (var i = 1; i <=cantidadEstudiantes; i++) {
          var nombreEstudiante = prompt('Ingrese el nombre del estudiante ' + i + ':');
  
          var sumaNotas = 0;
          var promedioNotas = 0;

      
          for (var j = 1; j <= 4; j++) {
              var nota = parseFloat(prompt('Ingrese la nota de la materia ' + j + ' para ' + nombreEstudiante + ':'));
              sumaNotas += nota;
          }
  
        
          promedioNotas = sumaNotas / 4;
  
      
          alert('El promedio de notas de ' + nombreEstudiante + ' es: ' + promedioNotas.toFixed(2));
  
      
          promedioGrupo += promedioNotas;
      }
  
      
          promedioGrupo /= cantidadEstudiantes;
     
  
      alert('El promedio general del grupo es: ' + promedioGrupo.toFixed(2));
  });




$("#consumo").click(function () {
    var cantidadClientes = parseInt(prompt('Ingrese la cantidad de clientes:'));
    var precioVatio = parseFloat(prompt('Ingrese el precio de cada vatio:'));
  
    var consumoTotal = 0;
    var consumoPromedio = 0;
  
    for (var i = 1; i <= cantidadClientes; i++) {
        var lecturaAnterior = parseFloat(prompt('Ingrese lectura anterior del cliente ' + i + ':'));
        var lecturaActual = parseFloat(prompt('Ingrese lectura actual del cliente ' + i + ':'));
    
        var consumoVatios = lecturaActual - lecturaAnterior;
    
        var costoCliente = consumoVatios * precioVatio;
    
        alert('Consumo del cliente ' + i + ': ' + consumoVatios.toFixed(2) + ' vatios');
        alert('Costo a pagar por el cliente ' + i + ': $' + costoCliente.toFixed(0));
    
        consumoTotal += consumoVatios;
    }
  
    consumoPromedio = consumoTotal / cantidadClientes;
  
    alert('Consumo total de todos los clientes: ' + consumoTotal.toFixed(2) + ' vatios');
    alert('Promedio de consumo por cliente: ' + consumoPromedio.toFixed(2) + 'vatios');
});




});


  











