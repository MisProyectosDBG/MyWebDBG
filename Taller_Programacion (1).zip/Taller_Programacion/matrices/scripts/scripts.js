jQuery('document').ready(function($){
   var menuBtn = $('.menu-icon');
   var menu = $('.navigation ul');
   var cedulas = new Array();
   var estudiantes = new Array();
   var edades = new Array();
   var matrices=new Array();
   var objestudiantes=new Array();
   
   var formulario=document.getElementById('formulario');
          formulario.addEventListener('submit',function(e){
           e.preventDefault();
        })
  

      menuBtn.click(function(){


        if (menu.hasClass('show')) {
          menu.removeClass('show');
        }else{
          menu.addClass('show');
      
        };
      });



////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {
    $("#boton_crearmatriz").click(function () {
        var filas = parseInt(prompt('Ingresa la cantidad de filas que tendrá tu matriz'));
        var columnas = parseInt(prompt('Ingresa la cantidad de columnas que tendrá tu matriz'));

       
        if (filas < 1 || filas !== columnas) {
            alert('Por favor, ingresa un número válido de filas y columnas.');
            return;
        }

        var matriz = [];
        for (var i = 0; i < filas; i++) {
            var fila = [];
            for (var j = 0; j < columnas; j++) {
                var numero = parseInt(prompt('Ingrese el número para la posición [' + i + '][' + j + ']:'));

                fila.push(numero);
            }
            matriz.push(fila);
        }

        mostrarMatriz(matriz);
        sumarMatriz(matriz);
    });
});

function mostrarMatriz(matriz) {
    var matrizStr = "";
    for (var i = 0; i < matriz.length; i++) {
        for (var j = 0; j < matriz[i].length; j++) {
            matrizStr += matriz[i][j] + "\t";
        }
        matrizStr += "\n"; 
    }
    alert(matrizStr);
}

function sumarMatriz(matriz) {
    var sumaHorizontal = new Array(matriz.length).fill(0);
    var sumaVertical = new Array(matriz.length).fill(0);   
    var sumaDiagonalPrincipal = 0;
    var sumaDiagonalSecundaria = 0;

    for (var i = 0; i < matriz.length; i++) {
        sumaDiagonalPrincipal += matriz[i][i];
        sumaDiagonalSecundaria += matriz[i][matriz.length - 1 - i];
        for (var j = 0; j < matriz[i].length; j++) {
            sumaHorizontal[i] += matriz[i][j];  
            sumaVertical[j] += matriz[i][j];
        }
    }

    for (var i = 0; i < sumaHorizontal.length; i++) {
        alert("Suma horizontal:\n" + "Fila " + (i + 1) + ": " + sumaHorizontal[i]);
    }

    
     for (var i = 0; i < sumaVertical.length; i++) {
        alert("Suma vertical:\n" + "Fila " + (i + 1) + ": " + sumaVertical[i]);
    }


    alert("Suma diagonal principal: " + sumaDiagonalPrincipal);
    alert("Suma diagonal secundaria: " + sumaDiagonalSecundaria);
}

    });



/////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {
    $("#boton_traspuesta").click(function () {
        var filas = parseInt(prompt('Ingresa la cantidad de filas que tendrá tu matriz'));
        var columnas = parseInt(prompt('Ingresa la cantidad de columnas que tendrá tu matriz'));

        if (filas < 1 || filas !== columnas) {
            alert('Por favor, ingresa un número válido de filas y columnas.');
            return;
        }

        var matriz = [];
        for (var i = 0; i < filas; i++) {
            matriz[i] = [];
            for (var j = 0; j < columnas; j++) {
                var numero = parseInt(prompt('Ingrese el número para la posición [' + i + '][' + j + ']:'));
                matriz[i][j] = numero;
            }
        }

      var transpuesta = [];
        for (var i = 0; i < filas; i++) {
            transpuesta[i] = [];
            for (var j = 0; j < columnas; j++) {
                transpuesta[i][j] = matriz[j][i];
            }
        }

        var matrizStr = "Matriz original:\n" + formatMatrix(matriz) + "\nMatriz transpuesta:\n" + formatMatrix(transpuesta);
        alert(matrizStr);
    });
});

/////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////////////////
$(document).ready(function() {
    $("#boton_multiplicacion").click(function () {
       
        var filas1 = parseInt(prompt('Ingresa la cantidad de filas de la primera matriz'));
        var columnas1 = parseInt(prompt('Ingresa la cantidad de columnas de la primera matriz'));

        var filas2 = parseInt(prompt('Ingresa la cantidad de filas de la segunda matriz'));
        var columnas2 = parseInt(prompt('Ingresa la cantidad de columnas de la segunda matriz'));



        var matriz1 = [];
        for (var i = 0; i < filas1; i++) {
            matriz1[i] = [];
            for (var j = 0; j < columnas1; j++) {
                var numero = parseInt(prompt('Ingrese el número para la posición [' + i + '][' + j + ']:'));
                matriz1[i][j] = numero;
            }
        }

        var matriz2 = [];
        for (var i = 0; i < filas2; i++) {
            matriz2[i] = [];
            for (var j = 0; j < columnas2; j++) {
                var numero = parseInt(prompt('Ingrese el número para la posición [' + i + '][' + j + ']:'));
                matriz2[i][j] = numero;
            }
        }

       
        var matrizResultado = [];
        for (var i = 0; i < filas1; i++) {
            matrizResultado[i] = [];
            for (var j = 0; j < columnas2; j++) {
                matrizResultado[i][j] = 0;
                for (var k = 0; k < columnas1; k++) {
                    matrizResultado[i][j] += matriz1[i][k] * matriz2[k][j];
                }
            }
        }  
        var matrizStr = "Matriz 1:\n" + formatMatrix(matriz1) + "\n\nMatriz 2:\n" + formatMatrix(matriz2) + "\n\nResultado:\n" + formatMatrix(matrizResultado);
        alert(matrizStr);
    });
});

function formatMatrix(matriz) {
    var matrizStr = "";
    for (var i = 0; i < matriz.length; i++) {
        for (var j = 0; j < matriz[i].length; j++) {
            matrizStr += matriz[i][j] + "\t";
        }
        matrizStr += "\n";
    }
    return matrizStr;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$(document).ready(function() {
    $("#boton_justicia").click(function () {
        var filas = parseInt(prompt('Ingresa la cantidad de filas que tendrá tu matriz'));
        var columnas = parseInt(prompt('Ingresa la cantidad de columnas que tendrá tu matriz'));

        var matriz = [];
        for (var i = 0; i < filas; i++) {
            var fila = [];
            for (var j = 0; j < columnas; j++) {
                var numero = parseInt(prompt('Ingrese el número para la posición [' + i + '][' + j + ']:'));
             
                fila.push(numero);
            }
            matriz.push(fila);
        }

        var matrizInversa = [];
        for (var i = filas - 1; i >= 0; i--) {
            matrizInversa.push([]);
            for (var j = columnas - 1; j >= 0; j--) {
                matrizInversa[filas - i - 1][columnas - j - 1] = matriz[i][j];
            }
        }

        var matrizStr = "Matriz original:\n";
        for (var i = 0; i < filas; i++) {
            for (var j = 0; j < columnas; j++) {
                matrizStr += matriz[i][j] + "\t";
            }
            matrizStr += "\n";
        }

        var matrizInversaStr = "Matriz inversa:\n";
        for (var i = 0; i < filas; i++) {
            for (var j = 0; j < columnas; j++) {
                matrizInversaStr += matrizInversa[i][j] + "\t";
            }
            matrizInversaStr += "\n";
        }

        alert(matrizStr + "\n" + matrizInversaStr);
    });
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

